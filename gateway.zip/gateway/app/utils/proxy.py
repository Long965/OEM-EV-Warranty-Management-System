# gateway/app/utils/proxy.py
import httpx
from fastapi import Request
from starlette.responses import Response, JSONResponse

async def proxy_request(request: Request, backend_url: str) -> Response:
    # Ghép URL backend + path thật
    path = request.url.path       # vd: /auth/login
    query = request.url.query     # vd: a=1&b=2

    target_url = backend_url + path
    if query:
        target_url += "?" + query

    # Copy body và headers
    body = await request.body()

    headers = dict(request.headers)
    headers.pop("host", None)
    headers.pop("content-length", None)

    try:
        async with httpx.AsyncClient() as client:
            response = await client.request(
                method=request.method,
                url=target_url,
                headers=headers,
                content=body
            )

        # Lọc headers nguy hiểm
        filtered_headers = {
            k: v for k, v in response.headers.items()
            if k.lower() not in ["transfer-encoding", "content-length"]
        }

        return Response(
            content=response.content,
            status_code=response.status_code,
            headers=filtered_headers,
            media_type=response.headers.get("content-type")
        )

    except httpx.ConnectError:
        return JSONResponse(
            content={"detail": "Backend service is unavailable"},
            status_code=503
        )
