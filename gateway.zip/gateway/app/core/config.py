import os

AUTH_SERVICE_URL = os.getenv("AUTH_SERVICE_URL")
USER_SERVICE_URL = os.getenv("USER_SERVICE_URL")
JWT_SECRET = os.getenv("JWT_SECRET")
