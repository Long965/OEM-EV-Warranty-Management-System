# gateway/app/core/jwt_handler.py
import jwt
import os
from fastapi import HTTPException
from starlette import status

# ✅ SỬA LỖI: Đảm bảo Gateway đọc JWT_SECRET từ biến môi trường
# Biến này được truyền từ docker-compose.yml
JWT_SECRET = os.getenv("JWT_SECRET", "fallback-secret-for-safety") 
ALGORITHM = "HS256"

class InvalidToken(HTTPException):
    def __init__(self, detail: str = "Invalid or expired token"):
        super().__init__(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=detail,
            headers={"WWW-Authenticate": "Bearer"},
        )

def decode_token(token: str) -> dict:
    """Giải mã token bằng khóa bí mật từ Auth Service."""
    try:
        # ✅ Nếu token sai, lỗi xảy ra ở đây
        payload = jwt.decode(token, JWT_SECRET, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise InvalidToken(detail="Token has expired")
    except jwt.InvalidTokenError:
        # Lỗi này thường do Khóa bí mật (JWT_SECRET) không khớp
        raise InvalidToken(detail="Invalid token")