# gateway/app/middleware/role_guard.py
from fastapi import Request, HTTPException
from functools import wraps

def require_roles(*roles):
    def decorator(func):
        @wraps(func)
        async def wrapper(request: Request, *args, **kwargs):
            user = getattr(request.state, "user", None)

            if not user:
                raise HTTPException(status_code=401, detail="Missing or invalid token")

            role = user.get("role") or user.get("role_name")
            print(f"--- DEBUG: Required Role: {roles} | Token Role: {role} ---") # <-- Thêm Log

            if role not in roles:
                raise HTTPException(status_code=403, detail="Access denied")

            return await func(request, *args, **kwargs)

        return wrapper
    return decorator