# gateway/app/routes/auth_router.py

from fastapi import APIRouter, Request
from app.utils.proxy import proxy_request
import os

BASE_URL_AUTH = os.environ.get("AUTH_URL", "http://auth_service:8001")

router = APIRouter(tags=["Authentication"])

@router.post(
    "/register",
    openapi_extra={
        "requestBody": {
            "required": True,
            "content": {
                "application/json": {
                    "schema": {
                        "type": "object",
                        "properties": {
                            "username": {"type": "string"},
                            "password": {"type": "string"},
                            "email": {"type": "string"},
                            "role_name": {"type": "string"}
                        },
                        "required": ["username", "password", "email", "role_name"]
                    }
                }
            }
        }
    }
)
async def proxy_register(request: Request):
    return await proxy_request(request, BASE_URL_AUTH)


@router.post(
    "/login",
    openapi_extra={
        "requestBody": {
            "required": True,
            "content": {
                "application/json": {
                    "schema": {
                        "type": "object",
                        "properties": {
                            "username": {"type": "string"},
                            "password": {"type": "string"}
                        },
                        "required": ["username", "password"]
                    }
                }
            }
        }
    }
)
async def proxy_login(request: Request):
    return await proxy_request(request, BASE_URL_AUTH)
