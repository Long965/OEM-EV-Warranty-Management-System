SERVICE_URLS = {
    "parts": "http://backend:8100/parts",
    "inventory": "http://backend:8100/inventory",
    "vehicles": "http://backend:8100/vehicles",
    "distribution": "http://backend:8100/distribution",
    "alerts": "http://backend:8100/alerts",
}
